<?php
// login.php

// Database configuration
$host = 'localhost';
$db = 'shopping_db';
$user = 'root';
$pass = '';

// Create a connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Validate login credentials (this is a simple example, you should use proper hashing and verification)
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id);
        $stmt->fetch();
        session_start();
        $_SESSION['user_id'] = $user_id;
        header("Location: dashboard.php");
    } else {
        echo "Invalid login credentials.";
    }
    
    $stmt->close();
}

$conn->close();
?>
