
<?php
// Database configuration
$host = 'localhost';
$db = 'shopping_db';
$user = 'root';
$pass = '';

// // Create a connection
// $conn = new mysqli($host, $user, $pass, $db);


        // Create a connection
        $conn = new mysqli("localhost", "root", "", "shopping_db");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$couponCode = '';
$discount = 0;
$message = '';

// Handle form submission for inserting a new coupon
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['new_coupon_code']) && isset($_POST['new_discount'])) {
    $newCouponCode = $_POST['new_coupon_code'];
    $newDiscount = $_POST['new_discount'];
    $expiryDate = date('Y-m-d', strtotime('+1 year')); // Set expiry date to 1 year from now

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO coupons (code, discount, expiry_date) VALUES (?, ?, ?)");
    $stmt->bind_param("sds", $newCouponCode, $newDiscount, $expiryDate);

    if ($stmt->execute()) {
        $message = "New coupon code added successfully!";
    } else {
        $message = "Error adding new coupon code.";
    }

    $stmt->close();
}

// Handle form submission for applying a coupon code
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['coupon_code'])) {
    $couponCode = $_GET['coupon_code'];
    
    // Prepare and bind
    $stmt = $conn->prepare("SELECT discount FROM coupons WHERE code = ? AND expiry_date >= CURDATE()");
    $stmt->bind_param("s", $couponCode);
    
    // Execute statement
    $stmt->execute();
    
    // Bind result variables
    $stmt->bind_result($discount);
    
    // Fetch value
    if ($stmt->fetch()) {
        $message = "Coupon code applied! You get a discount of $discount%.";
    } else {
        $message = "Invalid or expired coupon code.";
    }
    
    $stmt->close();
}

// Fetch all coupon codes from the database
$coupons = [];
$result = $conn->query("SELECT code, discount FROM coupons");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $coupons[] = $row;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discount Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        form input, form button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
        }
        form input[type="text"], form input[type="number"] {
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        form button {
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        form button:hover {
            background-color: #218838;
        }
        .message {
            text-align: center;
            margin: 20px 0;
            color: #d9534f;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        if ($message) {
            echo "<p class='message'>$message</p>";
        }
        ?>

        <h1>Add a New Coupon Code</h1>
        <form method="POST" action="discount.php">
            <label for="new_coupon_code">New Coupon Code:</label>
            <input type="text" id="new_coupon_code" name="new_coupon_code" required>
            <label for="new_discount">Discount (%):</label>
            <input type="number" id="new_discount" name="new_discount" step="0.01" required>
            <button type="submit">Add Coupon</button>
        </form>

        <h1>All Coupon Codes</h1>
        <table>
            <thead>
                <tr>
                    <th>Coupon Code</th>
                    <th>Discount (%)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($coupons as $coupon) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($coupon['code']); ?></td>
                        <td><?php echo htmlspecialchars($coupon['discount']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
