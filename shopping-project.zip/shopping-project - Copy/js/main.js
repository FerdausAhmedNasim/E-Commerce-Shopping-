/* ====================
bx slider
===================== */
$(document).ready(function(){
      $('#main_menu').meanmenu({
        meanMenuContainer: '#mobile_menu',
        meanScreenWidth: 991
      });
    });