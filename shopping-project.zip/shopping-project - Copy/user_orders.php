<?php include 'config.php'; ?>
<?php include 'header.php'; ?>

<?php
if (!session_id()) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_ids = rtrim($_POST['product_id'], ',');
    $totalAmount = $_POST['product_total'];
    $discount = isset($_POST['discount']) ? $_POST['discount'] : 0;

    // Calculate total amount after discount
    $totalAmountAfterDiscount = $totalAmount - ($totalAmount * ($discount / 100));

    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "shopping_db");
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert order details into 'order_products' table
    $stmt = $conn->prepare("INSERT INTO order_products (product_ids, total_amount, discount, total_amount_after_discount) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sddd", $product_ids, $totalAmount, $discount, $totalAmountAfterDiscount);

    if ($stmt->execute()) {
        $orderMessage = "Order has been placed successfully!";
    } else {
        $orderMessage = "Error placing order: " . $stmt->error;
    }

    $stmt->close();

    // Fetch product details
    $query = "SELECT product_title, featured_image FROM products WHERE product_id IN ($product_ids)";
    $result = $conn->query($query);

    echo "<div class='container'>";
    echo "<div class='row'>";
    echo "<div class='col-md-12'>";
    echo "<h2 class='section-head'>Order Summary</h2>";
    echo "<p>Total Amount: $totalAmount</p>";
    echo "<p>Discount: $discount%</p>";
    echo "<p>Total Amount After Discount: $totalAmountAfterDiscount</p>";

    if ($result->num_rows > 0) {
        echo "<h3>Products</h3>";
        echo "<div class='product-list'>";
        while ($row = $result->fetch_assoc()) {
            echo "<div class='product-item'>";
            echo "<img src='product-images/{$row['featured_image']}' alt='{$row['product_title']}' width='100px' />";
            echo "<p>{$row['product_title']}</p>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>No products found for the given IDs.</p>";
    }

    echo "<p>$orderMessage</p>";
    echo "</div>";
    echo "</div>";
    echo "</div>";

    $conn->close();
}
?>

<?php include 'footer.php'; ?>
